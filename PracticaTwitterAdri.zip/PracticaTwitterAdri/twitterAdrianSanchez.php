<?php
ini_set('display_errors', 1);
require_once('TwitterAPIExchange.php');

$settings = array(
    'oauth_access_token' => "3412880499-QdQKOUZhWEasEqNZUtHtlEzhO6Ki9gWZT1jamqn",
    'oauth_access_token_secret' => "jKoJPCslRUXrr5eWoTzjGN32mG8ioFIDxzFiLjRXtqGAT",
    'consumer_key' => "3KiRmk6ESaV184bFjUpw0JRef",
    'consumer_secret' => "1Nbg4djD6Z6HwKKMTANveLseM3UjNec7Muwx2WWyQKuKa9G3iY"
);

$url = 'https://api.twitter.com/1.1/blocks/create.json';
$requestMethod = 'POST';

$postfields = array(
    'screen_name' => 'usernameToBlock', 
    'skip_status' => '1'
);

$twitter = new TwitterAPIExchange($settings);
echo $twitter->buildOauth($url, $requestMethod)
             ->setPostfields($postfields)
             ->performRequest();

echo '<br><br>';
$url = 'https://api.twitter.com/1.1/statuses/lookup.json';
$getfield = '?id=nasa';
$requestMethod = 'GET';
$twitter = new TwitterAPIExchange($settings);
echo $twitter->setGetfield($getfield)
             ->buildOauth($url, $requestMethod)
             ->performRequest();